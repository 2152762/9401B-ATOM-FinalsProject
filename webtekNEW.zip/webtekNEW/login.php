<?php
require 'db.php';

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT student_id, type, firstname FROM accounts WHERE username = '$username' AND password = '$password'";
$res = $conn->query($sql);
if ($res->num_rows > 0) {
  session_start();
  $_SESSION['login'] = 1;
    $r = $res->fetch_row();
    if($r[1] == 'admin'){
        $_SESSION['idno'] = $r[0];
        $_SESSION['user_type'] = $r[1];
        $_SESSION['firstname'] = $r[2];
        header('Location: admin_requests.php');
    }else{
        $_SESSION['idno'] = $r[0];
        $_SESSION['user_type'] = $r[1];
        $_SESSION['firstname'] = $r[2];
        header('Location: student_page.php');
    }

} else {
    $m = "Error Username or Password!";
    echo "
            <script type = 'text/javascript'>
                alert('$m');
                window.location.replace('index.php');
            </script>";
}
