<?php

$conn = new mysqli("localhost","root","","webtech");
if(!$conn){
    var_dump($conn->error);
}
