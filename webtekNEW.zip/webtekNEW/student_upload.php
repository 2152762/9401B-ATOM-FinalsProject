<?php
session_start();
require 'db.php';

if (!(isset($_SESSION['login']) && $_SESSION['login'] != '')) {

  $m = "Please Login to continue!";
  echo "  <script type = 'text/javascript'>
              alert('$m');
              window.location.replace('index.php');
          </script>";

}
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <title>Form Petition</title>
    <!--    <link rel="stylesheet" type="text/css" href="styles/bootstrap.min.css">-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

</head>
<body>
<div class="container">
    <br>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="admin_requests.php">SAMCIS Petition</a>
            </div>
            <ul class="nav navbar-nav">
                <li><a href="student_page.php">Subjects</a></li>
                <li><a href="student_pending.php">Requests</a></li>
                <li><a href="student_requests.php">Status</a></li>
                <li class="active"><a href="student_upload.php">Uploads</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="#">
                        <?php
                        echo strtoupper($_SESSION['firstname']);
                        ?></a>
                </li>
                <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
            </ul>
        </div>
    </nav>
    <hr>
    <br>
    <div class="text-center">
        <h2>Uploads</h2>
    </div>
    <br>
    <br>
    <div class="row justify-content-center">
      <div>
        <form action="upload.php" method="POST" enctype="multipart/form-data">
          <h4>Select Image File to Upload:</h4>
          <input type="file" name="file">
          <input type="submit" name="submit" value="Upload">
        </form>
        <br>
        <br>
        <h4>Uploaded Images:</h4>
        <?php
          include('db.php');
          $query=mysqli_query($conn,"select * from images where ".$_SESSION['idno']." = student_id");
          while($row=mysqli_fetch_array($query)){
            ?>
              <img src="<?php echo $row['img_location']; ?>" class="img-rounded" alt="Unable to Load Image" width="307" height="240" />
            <?php
          }
        ?>
      </div>
    </div>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>

</div>
</body>
</html>
