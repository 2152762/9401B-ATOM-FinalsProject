const express = require('express');
const mongoose = require('mongoose');
var cookieSession = require('cookie-session');
var mysql = require('mysql');
const { check } = require('express-validator');
const router = express.Router();
var formidable = require('formidable');
var app = express();

app.set('trust proxy', 1) // trust first proxy

router.use(cookieSession({
  name: 'session',
  keys: ['key1', 'key2']
}));

router.get('/home', function (req, res){
	req.session.destroy();
	return res.status(200).send();
})

const {body, validationResult} = require('express-validator/check')

// renders home page
var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '',
  database : 'petition'
});

connection.connect(function(err) {
  if (err) throw err;
});

function querySubjects(res)
{
  connection.query('SELECT * from subjects', function (err, rows, fields) {
    if (err) throw err
    console.log('The solution is: ', rows)
    res.render('subjects', {subjects : rows});
  });
}

router.get('/', (req, res) => {
  if(req.session.loggedin){
    req.session.loggedin = null;
  var data = {};
  data.message = "Please Input Your ID Number"
  res.render('home', {data:data});
  console.log('sessions',req.session.loggedin)
  } else {
    var data = {};
  data.message = "Please Input Your ID Number"
  res.render('home', {data:data});
  }
});

router.get('/subject-list', (req, res) => {
  console.log(req.params.code)
  querySubjects(res);
});

router.get('/subject/:code/', (req, res) => {
  console.log('The code is: ', req.params.code)
  var query = "SELECT * from subjects WHERE Code ='" + req.params.code + "'";
  connection.query(query, function (err, result) {
    if (err) throw err
  
    console.log('The result is: ', result);
    var data = req.body;
    data.Code = req.params.code;
    data.Title = result[0].Title;
    req.session.title = result[0].Title;
    data.id = req.session.loggedin.idno;
    data.name = req.session.loggedin.name;
    data.courseyear = req.session.loggedin.course;
    res.render('petition', {data: data});
    })
  
});

router.post('/subject/:code/', (req, res) => {
  console.log('The code is: ', req.params.code)
  var data = req.body;
  data.Code = req.params.code;
  data.Title = req.session.title;
  var petData = {
    idno: req.session.loggedin.idno,
    subjCode: req.params.code
  }
  
  var queryIfExists = "select count(*) as count from petition where subjCode = ? and idno = ?";
  var formattedQuery = mysql.format(queryIfExists,[petData.subjCode,petData.idno]);
  console.log('formattedQuery', formattedQuery);
  var query = connection.query(formattedQuery,  (error,result) => {
    if(error){
      console.error('An Error occurred while executing the query')
      throw error;
    } 

    console.log('select count(*) result', result[0]);
    if (result[0].count > 0) {
      data.message = "you have already petitoned for this subject to check the list of students who have also petition for the subject click the VIEWLIST above";
      res.render('petition', {data: data});
    }
  });

  var queryIfExists = "select count(*) as count from petition where subjCode = ? and idno = ?";
  var formattedQuery = mysql.format(queryIfExists,[petData.subjCode,petData.idno]);
  console.log('formattedQuery', formattedQuery);
  var query = connection.query(formattedQuery,  (error,result) => {
    if(error){
      console.error('An Error occurred while executing the query')
      throw error;
    } 
if(result[0].count < 1){ 
  query.on('end', function() {
    console.log('select count(*) end');
    //tuloy ang ligaya, proceed to insert
    var insert = connection.query('INSERT INTO petition SET ?', petData, (error,results,fields) => {
      if(error){
        console.error('An Error occurred while executing the query')
        throw error;
      } 
    });

    insert.on('end', function() {
      data.message = "Petition successful";
      res.render('petition', {data: data});
    });
  });
}
});

});

router.post('/login', (req, res, next) => {
  console.log('The code is: ', req.body)
  var queryIfExists = "select *, count(idno) as count from data where idno = ?";
  var formattedQuery = mysql.format(queryIfExists,req.body.id);
  console.log('formattedQuery', formattedQuery);
  var query = connection.query(formattedQuery,  (error,result) => {
      if(error){
        console.error('An Error occurred while executing the query')
        throw error;
      } 

      // console.log('select count(*) result', result[0]);
      if (result[0].count < 1) {
        var data = {};
        data.message = "Invalid ID NUMBER";
        res.render('home', {data:data});
      }
      console.log('select count(*) result', result[0]);
      if (result[0].count > 0) {
        console.log('request',req.session.loggedin)
        req.session.loggedin = result[0];
        querySubjects(res);
      }
    });
}); 
router.post('/home', function(req,res){
  var data = {};
    if (req.session.loggedin) {
      // delete session object
      req.session.loggedin = null
      data.message = 'You have Been Logged out. Please Enter your ID number'
           res.render('home', {data:data});
           console.log('session', req.session.loggedin)
    }
  }); 

function petitionList(req,res)
{
  var data = {};
  connection.query("SELECT * FROM petition p, data d where p.idno = d.idno and p.subjCode = ? ", req.params.code ,
   function (err, rows, fields) {
    if (err) throw err
    data.subjCode = req.params.code;
    data.title = req.session.title;
    data.petData = rows;
    data.loggedin = req.session.loggedin.idno;

    res.render('viewlist', {data : data});
  });
}

router.get('/viewlist/:code/', (req, res) => {
  console.log('The code is: ', req.params.code)
  petitionList(req,res);
});

router.get('/petition-delete/:idno/:code/', (req, res) => {
  console.log('The idno is: ', req.params.code)
  connection.query("DELETE FROM petition where idno = '" + req.session.loggedin.idno + "'")
  petitionList(req,res);
});

router.post('/upload', (req, res) => {
  var form = new formidable.IncomingForm();

  form.parse(req);

  form.on('fileBegin', function (name, file){
      file.path = __dirname + '/uploads/' + file.name;
  });

  form.on('file', function (name, file){
      console.log('Uploaded ' + file.name);
  });
    var data = {};
    res.sendFile(__dirname);
    data.message = 'your file has been uploaded!'
    res.render('upload', {data:data})
});
module.exports = router;