const express = require('express');
var cookieSession = require('cookie-session');
var mysql = require('mysql');
const router = express.Router();
var formidable = require('formidable');
var app = express();

app.set('trust proxy', 1)

router.use(cookieSession({
  name: 'session',
  keys: ['key1', 'key2']
}));

router.get('/home', function (req, res){
	req.session.destroy();
	return res.status(200).send();
})

var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : '',
  database : 'petition'
});

connection.connect(function(err) {
  if (err) throw err;
});

function querySubjects(res)
{
  connection.query('SELECT * from subjects', function (err, rows, fields) {
    if (err) throw err
    console.log('The solution is: ', rows)
    res.render('subjects', {subjects : rows});
  });
}
// renders the login page
router.get('/', (req, res) => {
  if(req.session.loggedin){
    req.session.loggedin = null;
  var data = {};
  data.message = "Please Input Your ID Number"
  res.render('home', {data:data});
  console.log('sessions',req.session.loggedin)
  } else {
    var data = {};
  data.message = "Please Input Your ID Number"
  res.render('home', {data:data});
  }
});

router.get('/subject-list', (req, res) => {
  console.log(req.params.code)
  querySubjects(res);
});

// renders the petition page and sends all stored session information to the page
// @Author: Cruz,Vincent M
router.get('/subject/:code/', (req, res) => {
  console.log('The code is: ', req.params.code)
  var query = "SELECT * from subjects WHERE Code ='" + req.params.code + "'";
  connection.query(query, function (err, result) {
    if (err) throw err
  
    console.log('The result is: ', result);
    var data = req.body;
    data.Code = req.params.code;
    data.Title = result[0].Title;
    req.session.title = result[0].Title;
    data.id = req.session.loggedin.idno;
    data.name = req.session.loggedin.name;
    data.courseyear = req.session.loggedin.course;
    res.render('petition', {data: data});
    })
  
});

// this code in particular inserts the logged in students to the database 
// @Author: Cruz,vincent
router.post('/subject/:code/', (req, res) => {
  console.log('The code is: ', req.params.code)
  var data = req.body;
  data.Code = req.params.code;
  data.Title = req.session.title;
  var petData = {
    idno: req.session.loggedin.idno,
    subjCode: req.params.code
  }
  
  var queryIfExists = "select count(*) as count from petition where subjCode = ? and idno = ?";
  var formattedQuery = mysql.format(queryIfExists,[petData.subjCode,petData.idno]);
  console.log('formattedQuery', formattedQuery);
  var query = connection.query(formattedQuery,  (error,result) => {
    if(error){
      console.error('An Error occurred while executing the query')
      throw error;
    } 

    console.log('select count(*) result', result[0]);
    if (result[0].count > 0) {
      data.message = "you have already petitoned for this subject to check the list of students who have also petition for the subject click the VIEWLIST above";
      res.render('petition', {data: data});
    }
  });

  var queryIfExists = "select count(*) as count from petition where subjCode = ? and idno = ?";
  var formattedQuery = mysql.format(queryIfExists,[petData.subjCode,petData.idno]);
  console.log('formattedQuery', formattedQuery);
  var query = connection.query(formattedQuery,  (error,result) => {
    if(error){
      console.error('An Error occurred while executing the query')
      throw error;
    } 
if(result[0].count < 1){ 
  query.on('end', function() {
    console.log('select count(*) end');
    //tuloy ang ligaya, proceed to insert
    var insert = connection.query('INSERT INTO petition SET ?', petData, (error,results,fields) => {
      if(error){
        console.error('An Error occurred while executing the query')
        throw error;
      } 
    });

    insert.on('end', function() {
      data.message = "Petition successful";
      res.render('petition', {data: data});
    });
  });
}
});

});
  //in the login code, the code will first check if the user is a valid student by checking if the id number inputted is in the database
  // @Author Boguiles, Zyrey
router.post('/login', (req, res, next) => {
  console.log('The code is: ', req.body)
  var queryIfExists = "select *, count(idno) as count from data where idno = ?";
  var formattedQuery = mysql.format(queryIfExists,req.body.id);
  console.log('formattedQuery', formattedQuery);
  var query = connection.query(formattedQuery,  (error,result) => {
      if(error){
        console.error('An Error occurred while executing the query')
        throw error;
      } 

      if (result[0].count < 1) {
        var data = {};
        data.message = "Invalid ID NUMBER";
        res.render('home', {data:data});
      }
      console.log('select count(*) result', result[0]);
      if (result[0].count > 0) {
        console.log('request',req.session.loggedin)
        req.session.loggedin = result[0];
        querySubjects(res);
      }
    });
}); 
//for session destruction, the code will first check the saved session in the system, if the 'ifelse' returns true then the session will be destroyed
//@Author: Vincent Cruz
router.post('/home', function(req,res){
  var data = {};
    if (req.session.loggedin) {
      // delete session object
      req.session.loggedin = null
      data.message = 'You have Been Logged out. Please Enter your ID number'
           res.render('home', {data:data});
           console.log('session', req.session.loggedin)
    }
  }); 

function petitionList(req,res)
{
  var data = {};
  connection.query("SELECT * FROM petition p, data d where p.idno = d.idno and p.subjCode = ? ", req.params.code ,
   function (err, rows, fields) {
    if (err) throw err
    data.subjCode = req.params.code;
    data.title = req.session.title;
    data.petData = rows;
    data.loggedin = req.session.loggedin.idno;

    res.render('viewlist', {data : data});
  });
}

//in the viewlist, the petitionList function will query for the nesscesary data to be displayed
// @Author:Vincent Cruz
router.get('/viewlist/:code/', (req, res) => {
  console.log('The code is: ', req.params.code)
  petitionList(req,res);
});

//in deleting from the view list, upon clicking the button in the viewlist, the code will query a delete statement
//  @Author:Vincent Cruz
router.get('/petition-delete/:idno/:code/', (req, res) => {
  console.log('The idno is: ', req.params.code)
  connection.query("DELETE FROM petition where idno = '" + req.session.loggedin.idno + "'")
  petitionList(req,res);
});

router.get('/updateinformation', (req, res) => {
  var data = {};
  data.id = req.session.loggedin.idno;
  data.message = "Fill out the form below to update your student information"
  console.log('The code is: ', req.params.idno)
   res.render('updateinformation', {data:data})
});

  //Updates the information of the one logged in student
  //@Author: Boguiles, Zyrey
router.post('/updateinformation', (req, res) => {
  var query = "UPDATE data SET idno ='" + req.body.id + "', " + "name = '" + req.body.name + "', " + 
  "course ='" + req.body.courseyear + "'" + 
  " WHERE idno='"+ req.session.loggedin.idno+"'" 
  var data = {}
  data.id = req.session.loggedin.idno;
  data.message = "update Successful!"
	connection.query(query, function (err, result){
   res.render('updateinformation', {data:data});
 console.log('query', query)
	})
});

//this code is responsible for the uploading of files to the system files 
// @Author: Boguiles, Zyrey
router.post('/upload', (req, res) => {
  var form = new formidable.IncomingForm();

  form.parse(req);

  form.on('fileBegin', function (name, file){
      file.path = __dirname + '/uploads/' + file.name;
  });

  form.on('file', function (name, file){
      console.log('Uploaded ' + file.name);
  });
    var data = {};
    res.sendFile(__dirname);
    data.message = 'your file has been uploaded!'
    res.render('upload', {data:data})
});

// this code is responsible for rendering the form for registration
// @Author: Boguiles, Zyrey
router.get('/signup', (req, res) =>{
  res.render('register')
})

// this code is responsible for the inserting of the data of the user to the database
//@Author: Boguiles, Zyrey
router.post('/register', (req, res, next) =>{
  var student = {
    idno: req.body.id,
    name: req.body.name,
    course: req.body.courseyear
  }

  connection.query('INSERT INTO data SET ? ', student, function(err, res){
    if (err){
      console.log(err)
    }else{
      res.redirect('/');
    }
  })
});

// this code is responsible for rendering the form for adding subject
// @Author: Boguiles, Zyrey
router.get('/edit', (req, res) => {
  res.render('addsubject')
});

// this code is responsible for the inserting of the data of the subject to the databse
//@Author: Boguiles, Zyrey
router.post('/addsubject', (req, res, next)=>{
  var subject = {
    Code: req.body.code,
    Title: req.body.title
  }

  connection.query('INSERT INTO subjects SET ? ', subject, function(err, res){
    if (err){
      console.log(err)
    }else{
      console.log('success')
      res.redirect('viewlist')
    }
  })
});

module.exports = router; 