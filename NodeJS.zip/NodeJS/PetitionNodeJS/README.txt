extract file and go to the project folder from the terminal eg: "C:\Users\vincent\Desktop\9401B-ATOM\PROJECT"
import database to phpmyadmin in wamp
in the terminal either in command prompt of visual code type "npm run watch" inside the project folder

available students to petition:
2152727 juan dela cruz bsit3
2152626	juana dela cruz bsit3s