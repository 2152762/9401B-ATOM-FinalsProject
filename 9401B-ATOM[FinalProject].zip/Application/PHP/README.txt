*Note: must have a wamp server installed.
STEP 1: Copy the folder 'PetitionPHP' and paste it in C:\wamp64\www
STEP 2: Open WAMP server and run all services.
STEP 3: Open Chrome and login to localhost/phpmyadmin.
STEP 4: Create a new database and name it 'webtek'.
STEP 5: Import the 'webtech.sql' file that is included in the 'PetitionPHP' folder.
*Running the web application
STEP 6: Type in the url 'http://localhost/PetitionPHP'.
	-The user will be redirected to the login page.
STEP 7: To login as admin, the default username is 'admin' and password is also 'admin'.