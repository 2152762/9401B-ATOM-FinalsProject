<?php
/*
It Allows the student to petition for a subject.
Author: Jaybriane Tatel
*/
session_start(); // This resumes the saved user data.
require 'db.php'; // This will include the php file "db.php"
$id = $_GET['num'];
$idno = $_GET['idno'];
// This allows the student to join the subject and send the request to the admin.
$sql1 = "INSERT INTO petitions(subject_id, student_id, status) VALUES('$id','$idno','Accepted')";
$sql2 = "SELECT slots FROM subjects WHERE subject_id = '$id'"; // This is a sql query for slots
$r = $conn->query($sql2); // This will send a query to mySQL
$rr = $r->fetch_row(); // This will get the result from the query in MySQL
$slots = $rr[0] - 1; // subtracts 1 from the available slot if the student have petitioned
$sql3 = "UPDATE subjects SET slots = '$slots' WHERE subject_id = '$id'"; // This updates the slot when the student join the petition
if ($conn->query($sql1) == TRUE && $conn->query($sql3) == TRUE) {
    $m = "Petition Added!";
    echo "
            <script type = 'text/javascript'>
                alert('$m');
                window.location.replace('student_page.php');
            </script>";
} else {
    die($conn->error);
}
