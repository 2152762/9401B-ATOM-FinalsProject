<?php
/*
Allows the user to login and register.
Author: Russell Salio-an
*/
require 'db.php'; // This will include the php file "db.php"
session_start(); // This resumes the saved user data.
// It will check if login is set and if it is not blank, and also identifies if the user is a student or an admin.
if (isset($_SESSION['login']) && $_SESSION['login'] != '') {
      if($_SESSION['user_type'] == 'admin'){
          header('Location: admin_subjects.php');
      }else if($_SESSION['user_type'] == 'student'){
          header('Location: student_page.php');
      }
    }else {

    }

 ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SAMCIS Petition | Login</title>
    <link rel="stylesheet" href="styles/bootstrap.min.css">
    <!-- 
    This designs the signup form
    Author: Elena Consolacion
    --> 
    <style type="text/css">
        .login-form {
            width: 340px;
            margin: 50px auto;
        }

        .login-form form {
            margin-bottom: 15px;
            background: #f7f7f7;
            box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
            padding: 30px;
        }

        .login-form h2 {
            margin: 0 0 15px;
        }

        .form-control, .btn {
            min-height: 38px;
            border-radius: 2px;
        }

        .btn {
            font-size: 15px;
            font-weight: bold;
        }
    </style>
</head>
<!-- A form that will collect user information for login.
 -->
<body>    
<div class="login-form">
    <form action="login.php" method="post">
        <h1 class="text-center">SAMCIS</h1>
        <div class="form-group">
            <input type="text" name="username" class="form-control" placeholder="Username" required="required">
        </div>
        <div class="form-group">
            <input type="password" name="password" class="form-control" placeholder="Password" required="required">
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-primary btn-block">Log in</button>
        </div>
        <div class="clearfix text-center">
            <a href="signup.php">Sign up</a>
        </div>
    </form>
</div>
</body>
</html>
