<?php
/* 
This is the student page where the student can petition for a subject, view students who have petitioned, 
and upload image.
Author: Jaybriane Tatel
*/
session_start(); // This resumes the saved user data.
require 'db.php'; // This will include the php file "db.php"
if (!(isset($_SESSION['login']) && $_SESSION['login'] != '')) { // It will check if the user is logged in

  $m = "Please Login to continue!";
  echo "
          <script type = 'text/javascript'>
              alert('$m');
              window.location.replace('index.php');
          </script>";

}
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <title>Form Petition</title>
    <!--    <link rel="stylesheet" type="text/css" href="styles/bootstrap.min.css">-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

</head>
<body>
<!-- Bootstrap Template of the page-->
<div class="container">
    <br>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="student_page.php">SAMCIS Petition</a>
            </div>
            <ul class="nav navbar-nav">
                <li class="active"><a href="student_page.php">Subjects</a></li>
                
                
                <li><a href="student_upload.php">Uploads</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="#">
                        <?php
                        echo strtoupper($_SESSION['firstname']); // It will print the firstname of the student in ALL CAPITAL LETTER
                        ?></a>
                </li>
                <!-- It will logout the user -->
                <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
            </ul>
        </div>
    </nav>
    <hr>
    <br>
    <!-- It will print out the Subject name, minimum student for the subject, the slots, and action -->
    <div class="text-center">
        <h2>Available Subjects</h2>
    </div>
    <br>
    <br>

    <div class="row justify-content-center">
        <table class="table">
            <thead>
            <tr>
                <th>Name</th>
                <th>Minimum</th>
                <th>Slots</th>
                <th colspan="2">Action</th>

            </tr>
            </thead>
            <?php
            // It will show available subjects for petiton and the available slots  for the subject.
            $id = $_SESSION['idno'];
            $sql = "SELECT * FROM subjects"; // This will query in sql for subjects
            $res = $conn->query($sql); // This will send query to mySQL
            while ($row = $res->fetch_assoc()) { // This will generate when there is a subject and it will loop and print the result in the table
                $si = $row['subject_id'];
                $sql2 = "SELECT * FROM petitions WHERE (status = 'Accepted' OR status = 'Pending') AND subject_id = '$si' AND student_id = '$id'";
                echo "<tr>";
                echo "<td>" . $row['name'] . "</td>";
                echo "<td>" . $row['minimum'] . "</td>";
                echo "<td>" . $row['slots'] . "</td>";
                echo "  <td>
                        <a href='view_student_list.php?num=" . $row['subject_id'] .  "' class='btn btn-info'>View Students</a>&nbsp;";
                        // This will show the student the list of those student who petitioned for the subjects
                if($conn->query($sql2)->num_rows > 0){

                }else{
                    echo "<a href='join_subject.php?num=" . $row['subject_id'] . "&idno=" . $id . "' class='btn btn-success'>Join</a>"; 
                    //This will let the student to join the subject  for petition.
                }


                    echo "</td>
                </tr>";
            }
            ?>
        </table>
    </div>

    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>

</div>
</body>
</html>
