<?php
/* 
This adds a student account to the database.
Author: Russell Salio-an
*/
require 'db.php'; // This will include the php file "db.php"
session_start();  // This resumes the saved user data.

/* This are the post variables that contains the value of the user input from the signup page */
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$idno = $_POST['idno'];
$course = $_POST['course'];
$username = $_POST['username'];
$password = $_POST['password'];
// The account created will be saved on the database using the sql query below.

$sql = "INSERT INTO accounts(firstname, lastname, username, type, password, idno, course)
            VALUES('$firstname','$lastname','$username','student','$password','$idno','$course')"; 
// If the user have successfully registered, There will be an alert message that will say "Registration  successful!".
if ($conn->query($sql) === TRUE) {
    $m = "Registration successful!";
    echo "
            <script type = 'text/javascript'>
                alert('$m');
                window.location.replace('index.php');
            </script>";
} else {
    die($conn->error);
}
