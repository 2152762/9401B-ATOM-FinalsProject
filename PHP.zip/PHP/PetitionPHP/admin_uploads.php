<?php
/*
It allows the admin to view the uploads of the students
Author: Michael Ampaguey
*/
session_start(); // This resumes the saved user data.
require 'db.php'; // This will include the php file "db.php"
// It will check if the user is logged in
if (!(isset($_SESSION['login']) && $_SESSION['login'] != '')) {

  $m = "Please Login to continue!";
  echo "
          <script type = 'text/javascript'>
              alert('$m');
              window.location.replace('index.php');
          </script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>

    <title>Form Petition</title>
    <!--    <link rel="stylesheet" type="text/css" href="styles/bootstrap.min.css">-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

</head>
<body>
<!-- Bootstrap Template of the page 
     Ma. Elena Consolacion
-->   
<div class="container">
    <br>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="admin_requests.php">SAMCIS Petition</a>
            </div>
            <ul class="nav navbar-nav">
                
                <li><a href="admin_subjects.php">Subjects</a></li>
                <li class="active"><a href="admin_uploads.php">Uploads</a></li>
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li><a href="#">
                        <?php
                        echo strtoupper($_SESSION['firstname']); // It will print the firstname of the student in ALL CAPITAL LETTER
                        ?></a>
                </li>
                <li><a href="logout.php"><span class="glyphicon glyphicon-log-in"></span> Logout</a></li>
            </ul>
        </div>
    </nav>
    <hr>
    <br>
    <div class="text-center">
        <h2>Student Uploads</h2>
    </div>
    <br>
    <br>
    <form action="add_subject.php" method="post">
        <div class="row justify-content-center">
          <?php
            // It allows the admin to view the pictures that the students have uploaded using the sql query below.
            include('db.php'); // This will include the php file "db.php"
            // sql query for images
            $query=mysqli_query($conn,"select * from images join accounts on images.student_id = accounts.student_id");
            while($row=mysqli_fetch_array($query)){ // while there is a file, it will loop and print the result on the page
              ?>
              <div class="container">
                <h3><?php echo $row['firstname']." ".$row['lastname']; ?></h3>
                <img src="<?php echo $row['img_location']; ?>" class="img-rounded" alt="Unable to Load Image" width="307" height="240" />
              </div>
              <?php
            }
          ?>
        </div>
        <br>
        <br>
        <br>
    </form>


    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>

</div>
</body>
</html>
