<?php
/* 
This code lets the admin remove a student enrolled in a specific subject.
Author: Jaybriane Tatel
*/
session_start();  // This resumes the saved user data.
require 'db.php';  // This will include the php file "db.php"
$id = $_GET['num'];

$sid = $_GET['sid'];

$sql = "SELECT slots FROM subjects WHERE subject_id = '$sid'";  // This will query sql for slots
$r = $conn->query($sql); // This will send query to mySQL
$rr = $r->fetch_row(); // This will get the result to sql 

$slots = $rr[0] + 1; // This will add 1 to the slot if the student is removed
$sql2 = "UPDATE subjects SET slots = '$slots' WHERE subject_id = '$sid'"; // This will query sql for subjects
$conn->query($sql2); // This will send query to mySQL


$sql = "UPDATE petitions SET status = 'Canceled' WHERE petition_id = '$id'";
if ($conn->query($sql) === TRUE) {
    $m = "Request Cancelled!";
    echo "
            <script type = 'text/javascript'>
                alert('$m');
                window.location.replace('admin_subjects.php');
            </script>";
} else {
    die($conn->error);
}
