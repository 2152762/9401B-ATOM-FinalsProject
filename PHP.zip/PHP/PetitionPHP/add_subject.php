<?php
/*
This allows the admin to add a subject for petition.
Author: Jaybriane Tatel
*/
require 'db.php';
session_start();

$name = $_POST['name'];
$slots = $_POST['slots'];
$minimum = $_POST['minimum'];
$status = $_POST['status'];
//it allows the admin to add a new subject that will be open for petition using the sql query below
$sql = "INSERT INTO subjects(name, slots, minimum, status) VALUES('$name','$slots','$minimum','$status')";
if ($conn->query($sql) === TRUE) { // if the query that is sent to mySQL is TRUE, it will print "Added New Subject" and redirect the admin to the admin subject page.
    $m = "Added New Subject";
    echo "
            <script type = 'text/javascript'>
                alert('$m');
                window.location.replace('admin_subjects.php');
            </script>";
} else {
    die($conn->error);
}
