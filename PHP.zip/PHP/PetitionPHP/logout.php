<?php
/*
This code will end the session once the user logout and return to the login page.
Author: Russell Salio-an 
*/
require 'db.php';  // This will include the php file "db.php"
session_start(); // This resumes the saved user data.
session_destroy(); // This code ends the data registered to the current session.
header('Location:index.php'); // This will redirect the user to the file index.php or the login page.
?>
