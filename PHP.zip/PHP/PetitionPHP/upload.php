<?php
require 'db.php'; // include the db.php file
$statusMsg = '';
session_start(); // resumes the previous session


// this page allows the user to upload his/her picture. All pictures uploaded  
// will be showed also on the admin page.
$idnum = $_SESSION['idno'];

$targetDir = "uploads/";
$fileName = basename($_FILES["file"]["name"]);
$targetFilePath = $targetDir . $fileName;
$fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);

if(isset($_POST["submit"]) && !empty($_FILES["file"]["name"])){
  //checks if the user has chosen a file
    $allowTypes = array("jpg", "jpeg", "png", "JPG", "JPEG", "PNG");
    if(in_array($fileType, $allowTypes)){
      //checks if the selected file is allowed
        if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)){
          //moves the uploaded file into the designated target folder
            $insert = $conn->query("INSERT into images (img_location, student_id) VALUES ('".$targetDir.$fileName."', '".$idnum."')");
            if($insert){
              //checks if the file has been successfully uploaded
                //Author: Ampaguey, Michael Johnsson
                $statusMsg = "The file ".$fileName. " has been uploaded successfully.";
            }else{
                $statusMsg = "Upload failed.";
            }
        }else{
            $statusMsg = "An error occurred while uploading.";
        }
    }else{
        $statusMsg = 'Only JPG, JPEG, & PNG files are allowed to be uploaded.';
    }
}else{
    $statusMsg = 'Select your picture to be uploaded.';
}

echo "<script type = 'text/javascript'>
						alert('$statusMsg');
						window.location.replace('student_upload.php');
				</script>";
?>
