<?php
// It will access the database and will connect the application to mySQL.
// Author: Russell Salio-an
$conn = new mysqli("localhost","root","","webtech");
if(!$conn){
    var_dump($conn->error);
}
