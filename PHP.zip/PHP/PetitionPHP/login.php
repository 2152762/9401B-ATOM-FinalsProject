<?php
/* it allows the user to login the registered account. It will retrieve data from the database using the sql query.
Author: Russell Salio-an
*/
require 'db.php'; // This will include the php file "db.php"

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT student_id, type, firstname FROM accounts WHERE username = '$username' AND password = '$password'"; // Thii is the sql query for registered accounts
$res = $conn->query($sql); // This will send query to mySQL
if ($res->num_rows > 0) { // This will generate if there is a result in the query, the user will be loged in.
  session_start();
  $_SESSION['login'] = 1;
    $r = $res->fetch_row();
    if($r[1] == 'admin'){ // This will check if the user is an admin.
        $_SESSION['idno'] = $r[0];
        $_SESSION['user_type'] = $r[1];
        $_SESSION['firstname'] = $r[2];
        header('Location: admin_subjects.php');
    }else{
        $_SESSION['idno'] = $r[0];
        $_SESSION['user_type'] = $r[1];
        $_SESSION['firstname'] = $r[2];
        header('Location: student_page.php');
    }

} else { // This will generate if the user is a student
    $m = "Error Username or Password!";
    echo "
            <script type = 'text/javascript'>
                alert('$m');
                window.location.replace('index.php');
            </script>";
}
