<?php
/*
This allows the admin to delete a subject.
Author: Jaybriane Tatel
*/
session_start(); // This resumes the saved user data.
require 'db.php'; // This will include the php file "db.php"
$id = $_GET['num'];
// This allows the admin to delete the subject offered on the list
$sql = "DELETE FROM subjects WHERE subject_id = '$id'"; // sql query for deleting the subject
if ($conn->query($sql) === TRUE) { // This removes the deleted subject from the list
    $m = "Deleted!";
    echo "
            <script type = 'text/javascript'>
                alert('$m');
                window.location.replace('admin_subjects.php');
            </script>";
} else {
    die($conn->error);
}
